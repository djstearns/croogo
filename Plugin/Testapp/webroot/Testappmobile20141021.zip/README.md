AlloyAndroidiPhoneNavigationDemo
================================

Alloy/Titanium code used for the article: http://www.webdevd.com/titanium-alloy-android-iphone-ui-login-demo/
