//Completely Static!
Alloy.Globals.tabGroup = $.tabGroup;



