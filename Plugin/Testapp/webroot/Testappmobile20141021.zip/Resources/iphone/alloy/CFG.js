module.exports = {
    dependencies: {
        "nl.fokkezb.infiniteScroll": "1.3.1"
    }
};